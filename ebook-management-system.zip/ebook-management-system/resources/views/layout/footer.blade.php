<footer>
    <div class="container-fluid">
        <div class=" row">
            <div class="col">
                <h3 class="footer_heading">{{config("app.name")}}</h3></br>
                <p>Your favorite digital library and bookstore. Discover, buy, or borrow books from our extensive collection.</p>
            </div>

            <div class="col">
                <h4 class="footer_heading">Quick Links</h4>
                <p><a class="footer_link" href="{{ route('books.search') }}">Browse Books</a></p>
                <p><a class="footer_link" href="{{ route('books.search', ['sort' => 'latest']) }}">New Arrivals</a></p>
                <p><a class="footer_link" href="{{ route('books.search', ['sort' => 'best']) }}">Bestsellers</a></p>
                <p><a class="footer_link" href="login.php">My Account</a></p>
            </div>
            <div class="col">
                <h4 class="footer_heading">Categories</h4>
                <p><a class="footer_link" href="{{ route('books.search', ['filter' => 'fiction']) }}">Fiction</a></p>
                <p><a class="footer_link" href="{{ route('books.search', ['filter' => 'non_fiction']) }}">Non-Fiction</a></p>
                <p><a class="footer_link" href="{{ route('books.search', ['filter' => 'scifi']) }}">Science Fiction</a></p>
                <p><a class="footer_link" href="{{ route('books.search', ['filter' => 'romance']) }}">Romance</a></p>
            </div>
            <div class="col">
                <h4 class="footer_heading">Contact Us</h4>
                <p> <i class="bi bi-geo-alt icons"></i> Port Louis, Mauritius</p>
                <p> <i class="bi bi-telephone"></i> +230 123 4567</p>
                <p> <i class="bi bi-envelope-at"></i> contact@bibliohaha.mu</p>
            </div>
        </div>
    </div>

    <hr class="footer_divider">
    <p class="footer_copyright">Copyright &copy; 2025 bibliohaha. All rights reserved.</p>
    <br>
    <p><a class="footer_copyright footer_link" href="">Privacy Policy</a></p>
    <p><a class="footer_copyright footer_link" href="">Terms of Service</a></p>
    <p><a class="footer_copyright footer_link" href="">Support</a></p>

</footer>
